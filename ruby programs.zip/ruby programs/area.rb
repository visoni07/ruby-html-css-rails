puts "Enter length:"
l=   gets.chomp.to_f
puts "Enter width:"
w= gets.chomp.to_f
area= l*w
puts "Area of Rectangle is #{area}"
