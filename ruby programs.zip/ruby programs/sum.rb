puts "Enetr first value:"
num1 = gets.chomp.to_i
puts "Enetr second value:"
num2 = gets.chomp.to_i
sum=num1+num2
puts "The sum is #{sum}"
