def pow (a,b)
    power =1
    for i in 1..b

end
 return power
 end
 puts "Enter Base :-"
    base =gets.chomp.to_i
 puts "Enetr exponent :-"
    expo = gets.chomp.to_i
 puts "The power  is  #{power (base, expo)}"

