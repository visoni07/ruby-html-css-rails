class ApiController < ActionController::API
end
